var doc_datatypes =
[
    [ "Built-in types", "doc_builtin_types.html", "doc_builtin_types" ],
    [ "Add-on types", "doc_addon_types.html", "doc_addon_types" ]
];